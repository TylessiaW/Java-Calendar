package ds.Calendar;

public class Calendar {
    private static final int MAXEVENTS = 4;
    private Event[] events;
    private int numEvents;

    public Calendar() {
  
    }

    public boolean addEvent(Event e) {
 
        return false;
    }

    public int findEvent(Event e) {

        return -1;
    }

    public boolean removeEvent(Event e) {

        return false;
    }

    public void dump() {
    
    }
}
